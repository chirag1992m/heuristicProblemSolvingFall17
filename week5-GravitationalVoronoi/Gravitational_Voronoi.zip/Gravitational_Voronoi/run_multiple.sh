for i in {1..20}
do
	stones=$((i % 12))
	stones=$((stones + 1))
	python voronoi_game.py $stones 2 'localhost' 8000
done
 
