#!/bin/sh
cd "$( dirname "${BASH_SOURCE[0]}" )"
python s.py
