package edu.nyu.cs.hps.evasion.game;

import java.awt.*;

public interface Wall {

  boolean occupies(Point point);

}
